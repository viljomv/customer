import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../validation.service';
import {ApiService} from '../api.service'
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private fb:FormBuilder,private route:Router,private validation:ValidationService, private api:ApiService) {
    

   }
   validationMessages ={
    'title':{
      'required':'title is required',
    },
      'name':{
        'required':'first name is required'
      },
      'name1':{
        'required':'last name is required'
      },
      'guardian':{
        'required':'guardian is required' 
      },
      'name2':{
        'required':' guardian is required' 
      },
      'date':{
        'required':' date is required' 
      },
      'age':{
        'required':' age is required' 
      },
      'address':{
        'required':' address is required' 
      },
      'city':{
        'required':' city is required' 
      },
      'district':{
        'required':' district is required' 
      },
      'state':{
        'required':' state is required' 
      },
      'country':{
        'required':' country is required' 
      },
      'pin':{
        'required':' pin is required' 
      },
      'exp':{
        'required':' experience is required' 
      },
      
      

   
    
  };
  formErrors={title:'',
  name:'',
  name1:'',
  guardian:'',
  name2:'',
  date:'',
  age:'',
  address:'',
  city:'',
  district:'',
  state:'',
  country:'',
  pin:'',
  exp:'',

};
customerForm= this.fb.group({
  title:['',Validators.required],
  name:['',Validators.required],
  name1:['',Validators.required],
  guardian:['',Validators.required],
  name2:['',Validators.required],
  date:['',Validators.required],
  age:['',Validators.required],
  address:['',Validators.required],
  city:['',Validators.required],
  district:['',Validators.required],
  state:['',Validators.required],
  country:['',Validators.required],
  pin:['',Validators.required],
  exp:['',Validators.required],
})
logValidationErrors(){
  this.formErrors=this.validation.getValidationErrors(this.customerForm,this.validationMessages )
}

   customer(){
    //  console.log('data',this.customerForm.value);
    // if(this.customerForm.valid){
    //   alert("successfully register")
      
    // }else{
    //   // alert("invalid registeration")
    // }
    this.logValidationErrors

    
    this.api.addUser(this.customerForm.value).subscribe(data=>{
      console.log(data);
      
    })
     

   }
   ngOnInit():void {
    this.customerForm.valueChanges.subscribe(
      value=>{
        this.logValidationErrors()
      }
    );
  
  }
 
  
}
