import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../validation.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {



  constructor( private fb:FormBuilder,private route:Router,private validation:ValidationService) { }
  validationMessages ={
    'user':{
      'required':'email is required',
    },
      'password':{
        'required':'password is required'
      }
    
  };

  formErrors={user:'',
  password:''};
    
  loginForm = this.fb.group({
    user:['',Validators.required],
    password:['',Validators.required]
  })

  logValidationErrors(){
    this.formErrors=this.validation.getValidationErrors(this.loginForm,this.validationMessages)
  }

 login (){
   if(this.loginForm.valid){
     alert("success")
     this.route.navigateByUrl("customer")
   }
   else{
    this.logValidationErrors()
    }
 
  }

  ngOnInit():void {
    this.loginForm.valueChanges.subscribe(
      value=>{
        this.logValidationErrors()
      }
    );
  
  }
}
