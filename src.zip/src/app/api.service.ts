import { Injectable } from '@angular/core';
import{HttpClient,HttpHeaders} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { 
    let headers: HttpHeaders = new HttpHeaders();
    headers = headers.append('HttpHeader1', 'Accept:application/json');
    headers = headers.append('HttpHeader2', 'zumo-api-version:2.0.0');
  }


  addUser(body:any){
   return this.http.post('http://192.168.12.10/custregistration/api/Customers/DataAdd',
   {Headers},body);
  }
}

